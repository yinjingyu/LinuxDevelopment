/*
 * =====================================================================================
 *
 *       Filename:  CClientBusinessForExecObj.cpp
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  2013年10月18日 17时01分01秒
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  YOUR NAME (), 
 *   Organization:  
 *
 * =====================================================================================
 */

#include "../include/CClientBusinessForExecObj.h"

CClientBusinessForExecObj::CClientBusinessForExecObj()
{

}

CClientBusinessForExecObj::~CClientBusinessForExecObj()
{

}
